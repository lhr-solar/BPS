//Fred Engelkemeir
//summer/fall 2012
//master's I2C driver

void I2C_init(void);

void I2C_init(void)
{
	
}
	