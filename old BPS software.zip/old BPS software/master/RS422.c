/********************************************
/RS422.c
/Implements the RS485 bus master
/uses UART2 and TIMER3
/"controller" refers to the BeagleBone or PC running the GUI configurator
********************************************/

#include <p30F6012A.h>

#define RS422_START_TOKEN 0x01
#define RS422_END_TOKEN 0xFE
#define RS422_TIMEOUT 25000 //10ms timeout
#define RS422_BPS_DEV_ID 1

unsigned char RS422_outData[255];					//data to controller
unsigned char RS422_inData[255];					//data from controller
unsigned char RS422_inDevID;						//device ID from Master
unsigned char RS422_inCommand;						//command from the controller
unsigned char RS422_outResponse;						//response/data-ID to the controller
unsigned char RS422_outChecksum;					//checksum to send 
unsigned char RS422_inChecksum;						//checksum from controller
unsigned char RS422_outLength;						//DATA length on output packets
unsigned char RS422_inLength;						//DATA length on input packets
unsigned char RS422_inDataPointer;					//array element pointer when receiver DATA from controller
unsigned char RS422_inStep;							//which section of packet we are receiving
unsigned char RS422_outStep;						//which section of packet we are sending
unsigned char RS422_outDataPointer;					//array element pointer when sending DATA to controller
unsigned char RS422_goodPacket;						//controller sent a good packet
				
void RS422_processPacket(void);
void RS422_sendPacket(void);
void RS422_initialize(void);
unsigned char RS422_ready(void);
//unsigned int  RS485_combineBytes(unsigned char MSB, unsigned char LSB);
//unsigned char RS485_splitMSB(unsigned int input);
//unsigned char RS485_splitLSB(unsigned int input);




void RS422_sendPacket(void)
{
	RS422_outChecksum = 0;			//initialize checksum
	RS422_outStep = 0;				//start at step 0
	RS422_outDataPointer = 0;		//start at first byte of response data/payload array
	U2TXREG = RS422_START_TOKEN;	//put start token in Transmit register
}

void RS422_initialize()
{
//set up the inter-byte receive timeout timer (Timer3)
	T3CONbits.TGATE = 0;	//don't gate it
	T3CONbits.TCKPS0 = 0;	//1:1 (no) prescaller
	T3CONbits.TCKPS1 = 0;
	T3CONbits.TCS = 0;		//use Fcy clock
	PR3 = RS422_TIMEOUT;	//load the timer period register
	IFS0bits.T3IF = 0;		//clear interrupt flag
	IEC0bits.T3IE = 1;		//enable interrupt
	T3CONbits.TON = 0;

//Set U1MODE (UART1 Mode Register) options 
// <15>  UARTEN = 1  UART Enable bit
// <13>  USIDL  = 0  Continue operation in Idle mode
// <10>  ALTIO  = 0  UART communicates using UxTX and UxRX I/O pins
// <7>   WAKE   = 1  Wake-up on Start bit Detect During Sleep Mode enabled
// <6>   LPBACK = 0  Loopback mode is disabled
// <5>   ABAUD  = 1  Auto Baud Enable bit, Input to Capture module from UxRX pin
// <2:1> PDSEL  = 00 8-bit data, no parity
// <0>   STSEL  = 1  2 Stop bits
// U1MODE = 1000 0000 1010 0001
	U2MODE = 0x80A1;
	U2MODEbits.ABAUD = 0;

//Set U1STA (UART1 Status and Control Register) options
// <15>  UTXISEL = 1  Interrupt when a character is transferred to the Transmit Shift 
//                    register and as result, the transmit buffer becomes empty
// <11>  UTXBRK  = 0  U1TX pin operates normally
// <10>  UTXEN   = 1  UART transmitter enabled, UxTX pin controlled by UART (if UARTEN = 1)
// <7:6> URXISEL = 00 Interrupt flag bit is set when Receive Buffer receives 1 character(1 byte of data)
// <5>   ADDEN   = 0  Address Detect mode disabled. If 9-bit mode is not selected, this control bit has no effect.
// U1STA = 1000 0100 0000 0000
	U2STA = 0x8400;

//Set U1BRG (UART1 Baud Rate Register) options
// U1BRG = (Fcy/(16*BaudRate)) - 1 = 0 for 625 kbaud
	U2BRG = 15; //close to 9600 buad


	IFS1bits.U2TXIF = 0;
	IFS1bits.U2RXIF = 0;
	IEC1bits.U2TXIE = 1;
	IEC1bits.U2RXIE = 1;
}

void __attribute__((__interrupt__, auto_psv)) _U2TXInterrupt(void)
{	//gets called whenever the TXbuffer is empty. so this code basically runs right when the previously sent byte's start bit heads down the wire
	IFS1bits.U2TXIF = 0;
	if(RS422_outStep == 0)						//just finished from step 0, outputting the start token
	{											//so we output the length
		U2TXREG = RS422_outLength;				//queue up the response packet length field
		RS422_outChecksum += RS422_outLength;	//add sent byte to checksum
		RS422_outStep = 1;						//just finished step 1
		return;									//exit from ISR					
	}
	else if (RS422_outStep == 1)				//just finished from step 1, outputting the length
	{											//so we send the master-ID code
		U2TXREG = RS422_BPS_DEV_ID;					//send out the slave-ID
		RS422_outChecksum += RS422_BPS_DEV_ID;		//add to checksum	
		RS422_outStep = 2;						//just finished step 2
		return;									//exit from ISR
	}
	else if (RS422_outStep == 2)				//just finished step 2, outputting the master-ID
	{											//now send the status
		U2TXREG = RS422_outResponse;			//put response in serial port transmit waiting hold
		RS422_outChecksum += RS422_outResponse;		//add to the checksum
		if (RS422_outLength == 0)				//check to see if there are any DATA/PAYLOAD byte(s) to send
			RS422_outStep = 4;					//if there aren't any, we just finished "sending" the non-existant data (step4), go to the step after send-DATA
		else	
			RS422_outStep = 3;					//just finished step 3, no goto step 4
		return;									//exit ISR
	}
	else if (RS422_outStep == 3)				//just finished sending the status-response byte, and there's data to send
	{											//now send response-DATA 
		if (RS422_outLength <= (RS422_outDataPointer+1))				//either only one byte for response-DATA, or need to send out last data byte
		{	
			U2TXREG = RS422_outData[RS422_outDataPointer];	//send data byte
			RS422_outChecksum += RS422_outData[RS422_outDataPointer];	//add data byte to the checksum
			RS422_outStep = 4;					//just finished sending the DATA, step 4, so goto step 5, sending checksum				
			return;								//exit ISR								
		}
		else									//we have at least one more byte to send after this
		{
			U2TXREG = RS422_outData[RS422_outDataPointer];	//send data byte
			RS422_outChecksum += RS422_outData[RS422_outDataPointer];	//add data byte to the checksum
			RS422_outDataPointer += 1;			//increment to the next data byte (to be sent next cycle)
			return;								//exit ISR
		}
	}
	else if (RS422_outStep == 4)				//just finished from step 4, outputting the DATA (or we skipped it)
	{											//so we send the checksum
		RS422_outChecksum = ~RS422_outChecksum; //complement the checksum
		U2TXREG = RS422_outChecksum;			//send out the checksum
		RS422_outStep = 5;						//just finished step 5
		return;									//exit from ISR
	}
	else if (RS422_outStep == 5)				//just finished from step 5, outputting the checksum
	{											//so we send the end-token
		U2TXREG = RS422_END_TOKEN;				//send out the end toekn
		RS422_outStep = 6;						//now we're done with the sending
		return;									//exit from ISR
	}
	else if (RS422_outStep == 5)
	{
		RS422_outStep = 0;						//TXREG is empty, this means that end-token has been sent and that the junk-byte is about to be shifted out, so set to receive mode				
	}	
	return;									//exit ISR, we're done sending the packet. the ISR shouldn't be called again unless the RS485_sendResponse is called since the UART TX is empty
}

//interrupt for when the RS485 receives a byte
void __attribute__((__interrupt__, auto_psv)) _U2RXInterrupt(void)
{
	
	unsigned char temp;							//holds the last received byte
	IFS1bits.U2RXIF = 0;

	if (RS422_inStep == 0)
	{											//this is the first byte received
		temp = U2RXREG;
		if (temp == RS422_START_TOKEN)
		{
			TMR3 = 0;							//reset the timer
			T3CONbits.TON = 1;					//start the timer
			PR3 = RS422_TIMEOUT;				//switch the timer over from the (long) slave-thinking timer to the inter-byte timer
			RS422_inStep = 1;					//just finished the first step (start token)
			return;								//exit interrupt handler
		}
		else
		{
			return;								//exit interrupt handler
		}
	}
	else if (RS422_inStep == 1)
	{											//this is the second (length) byte
		TMR3 = 0;								//reset the timer
		temp = U2RXREG;							//read out of the receiver  buffer (can only do once, as its a FIFO?, hence the temp variable)
		RS422_inLength = temp;					//set packet length
		RS422_inChecksum += temp;				//add to the checksum
		RS422_inStep = 2;						//just finished the second step (length)
		return;									//exit ISR
	}
	else if (RS422_inStep == 2)
	{
		TMR3 = 0;								//reset the timer
		temp = U2TXREG;
		if(temp == RS422_BPS_DEV_ID)					//packet is for the master?
		{									//yes it is for me
			RS422_inChecksum += temp;			//add to checksum
		}
		else
		{
			RS422_goodPacket = 0;
		}
									//crap packet, no need to worry about checksum from now on....
		RS422_inStep = 3;
		return;
	}
	else if (RS422_inStep == 3)					//if we're on the command step
	{
		TMR3 = 0;								//reset the timer
		temp = U2RXREG;
		if (RS422_goodPacket)					//only do stuff with the byte if it's a packet we care about
		{
			RS422_inCommand = temp;				//set the command
			RS422_inChecksum += temp;			//add to checksum
		}
		if(RS422_inLength)						//if DATA field length non-zero
			RS422_inStep = 4;					//go to the data packet reception step
		else
			RS422_inStep = 5;					//if no data packet contents, skip that step
		return;	
	}
	else if (RS422_inStep == 4)
	{
		TMR3 = 0;								//reset the timer
		temp = U2RXREG;
		if (RS422_goodPacket)
		{
			RS422_inChecksum += temp;
			RS422_inData[RS422_inDataPointer] = temp;
		}
		RS422_inDataPointer += 1;
		if(RS422_inDataPointer >= RS422_inLength)	//did we get the last data byte?
			RS422_inStep = 5;						//then go to the next step
		return;										//othewise just come back here and grab the next data byte
	}
	else if (RS422_inStep == 5)
	{
		TMR3 = 0;								//reset the timer
		temp = U2RXREG;
		RS422_inChecksum = ~RS422_inChecksum;		//bitwise invert the checksum 
		if(temp != RS422_inChecksum)				//if the checksums don't match
			RS422_goodPacket = 0;					//then the packet is no good
		RS422_inStep = 6;		
		return;
	} 
	else if (RS422_inStep == 6)
	{
		T3CONbits.TON = 0;								//turn off the timer
		if( RS422_goodPacket && (U2RXREG == RS422_END_TOKEN))		
		{	//we have a good packet here, process it
			RS422_inStep = 0;
			RS422_inDataPointer = 0;
			RS422_processPacket();
		}
		else
		{	//we have a bad packet, so reset for the next one
			RS422_inStep = 0;
			RS422_inDataPointer = 0;
		}
		return;
	}
	
	//shouldn't get here
	//unless this interrupt triggers while we are processing/sending a packet (shouldn't happen)
	T3CONbits.TON = 0;

}


void __attribute__((__interrupt__, auto_psv)) _T3Interrupt(void)
{
	IFS0bits.T3IF = 0;
	T3CONbits.TON = 0;
	RS422_inStep = 0;
	RS422_inDataPointer = 0;
}

//returns 1 if ready, 0 if busy (waiting or transmitting)
unsigned char RS422_ready(void)
{
	return (RS422_outStep == 0);
}

void RS422_processPacket(void)
{
}


//newline
