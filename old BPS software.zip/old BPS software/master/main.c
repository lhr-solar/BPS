#include <p30F6012A.h>

void initialize(void);
void serialStim(void);
unsigned char GetReadings(unsigned char whichArray);
unsigned char Measure(void);
void unpackVolts(void);
void unpackTemps(void);
void WDT_service(void);		//feed the watchdog timer
void serviceMiscTask(void);
void serviceCommands(void);
unsigned char checkLimits(void);
void updateSOC(void);
void contactorControl(unsigned char battLimitStatus);

extern unsigned char RS485_command;
extern unsigned char RS485_slave;
extern unsigned char RS485_outLength;
extern unsigned char RS485_outData[];
extern unsigned char RS485_inData[];
extern unsigned char RS485_inLength;
extern unsigned char RS485_receive;
extern signed int ADC_current;

unsigned int batteryVoltsA[128];
unsigned int batteryTempsA[128];
unsigned int batteryVoltsB[128];
unsigned int batteryTempsB[128];
unsigned int slaveVolts[12];
unsigned int slaveTemps[12];
unsigned int SOCarray[128];
unsigned char arrayAgood;
unsigned char arrayBgood;
unsigned char currentA;
unsigned char currentB;
unsigned char BPSstate;		//0 = system is "off" and not measuring any cells, contactor is off
							//1 = system is measuring cell values but contactor is off
							//2 = system is on measuring cells and the contactor is on
							//3 = system is tripped, also is measuring batteries, contacotr off
							//4 = system has an error, contactor off, not measuring
unsigned char lastWDToutput;

int main(void)
{
	unsigned char battOK;
	initialize();
	serialStim();
	
	while(1)
	{
		Measure();
		battOK = checkLimits();
		contactorControl(battOK);
		serviceCommands();
		WDT_service();
		updateSOC();
	}	
	for(;;);
}



void initialize(void)
{
	lastWDToutput = 0;
	arrayAgood = 0;
	arrayBgood = 0;
	misc_initialize();
	I2C_init();
	RS485_initialize();
	RS422_initialize();
	ADC_initialize();
}


serialStim()
{

	while(!misc_isDebug());		//wait until DEBUG is turned on
	RS485_command = 100;
	RS485_slave = 1;
	RS485_outLength = 0;
	RS485_sendPacket(1);
	while(!RS485_ready());		//wait to send the 100 cmd
	RS485_command = 101;
	RS485_outLength = 0;
	RS485_slave = 1;
	RS485_sendPacket(1);
	//return;
	while(!RS485_ready());		//wait for a timout on resp to 101 cmd
	RS485_command = 100;
	RS485_slave = 1;
	RS485_outLength = 0;
	RS485_sendPacket(1);
	while(!RS485_ready());		//wait to send the 100 cmd
	RS485_command = 1;
	RS485_outLength = 0;
	RS485_slave = 1;
	RS485_sendPacket(1);
	while(!RS485_ready());		//wait for the ident response

	
	RS485_command = 2;
	RS485_outData[0] = 1;
	RS485_outData[1] = 1;
	RS485_outData[2] = 11;
	RS485_outData[3] = 8;
	RS485_outLength = 4;
	RS485_slave = 1;
	RS485_sendPacket(1);
	while(!RS485_ready());		//wait for the reg write response

	RS485_command = 2;
	RS485_outData[0] = 1;
	RS485_outData[1] = 1;
	RS485_outLength = 2;
	RS485_slave = 1;
	RS485_sendPacket(1);
	while(!RS485_ready());		//wait for the reg read response
/*
	while(misc_isDebug())
	{
		RS485_command = 150;
		RS485_outLength = 0;
		RS485_slave = 1;
		RS485_sendPacket(1);
		while(!RS485_ready());		//wait for a response on turning on the LED
		RS485_command = 160;
		RS485_outLength = 0;
		RS485_slave = 1;
		RS485_sendPacket(1);
		while(!RS485_ready());		//wait for a response on turning off the LED
	} */
}
//reads in stuff from the ADC and the polls the (normal) slaves for voltages and temperatures. scales it all, and combines it into the propper arrays
//returns 0 for sucess
//returns 1 for a fault (i.e. slave no response)
//whichArray is a 0 for making it fill into arrays A, and a 1 for filling array set B
unsigned char GetReadings(unsigned char whichArray)
{
	unsigned char currentSlave = 1;		//the slave we are currently interrogating, has NOTHING to do with the current sensor slave board!
	unsigned char cellsHandled = 0;
	unsigned char commError = 0;
	unsigned char slaveCellCtr;
	ADC_start();
	while((currentSlave < 16) && (cellsHandled < reg_read(3,1))) //loop through all slaves untill all cells are accounted for (or we run out of slaves)
	{	
		if(reg_read(2, currentSlave) > 12 || reg_read(2, currentSlave) == 0) //skip this loop altogether if no cells on this slave, or too many
		{
			currentSlave++;
			continue;
		}	
		//TODO: commError += send read command and wait for response (and do retrys)
		//retry if failed
		//if failed, it should fill volt and temp array with 0's
		//do for both temp and volt 
		
		if(whichArray)
		{
			for(slaveCellCtr = 0; slaveCellCtr < reg_read(2, currentSlave); slaveCellCtr++)
			{
				batteryVoltsB[cellsHandled+slaveCellCtr] = slaveVolts[slaveCellCtr];
				batteryTempsB[cellsHandled+slaveCellCtr] = slaveTemps[slaveCellCtr];
			}	
		}
		else
		{
			for(slaveCellCtr = 0; slaveCellCtr < reg_read(2, currentSlave); slaveCellCtr++)
			{
				batteryVoltsA[cellsHandled+slaveCellCtr] = slaveVolts[slaveCellCtr];
				batteryTempsA[cellsHandled+slaveCellCtr] = slaveTemps[slaveCellCtr];
			}	
		}
		cellsHandled += reg_read(2, currentSlave); 
		currentSlave++;
	}	
	while(!ADC_done()); //wait for ADC to finish (it should have finished before the first slave responds)
	ADC_scale();
	if(whichArray)
		currentB = ADC_current;
	else	
		currentA = ADC_current;
	return commError;
}	

//reads in the battery parameters. calls GetReadings, and switches between the two arrays.
//returns 0 for OK, or a 1 for some error
unsigned char Measure()
{
	unsigned char error;
	unsigned char workingOnA;
	if ((BPSstate == 0) || (BPSstate == 4))
	{
		serviceMiscTask();
		return 0;
	}	
	if(arrayAgood)			//we did A last time
	{						//so we're doing B now
		workingOnA = 0;
		arrayBgood = 0;		
	}
	else					//we did B last time (or first run)
	{
		workingOnA = 1;
		arrayAgood = 0;
	}
	if(workingOnA)
	{
		error = GetReadings(0);
		arrayAgood = 1;
	}	
	else
	{
		error =  GetReadings(1);
		arrayAgood = 1;
	}
	return error;
}	

void unpackVolts(void)
{
	unsigned char i;
	for (i = 0; (2*i) < RS485_inLength; i++)
	{
		slaveVolts[i] = RS485_combineBytes(RS485_inData[2*i], RS485_inData[(2*i)+1]); //MSB, LSB
	}	
}	
void unpackTemps(void)
{
	unsigned char i;
	for (i = 0; (2*i) < RS485_inLength; i++)
	{
		slaveTemps[i] = RS485_combineBytes(RS485_inData[2*i], RS485_inData[(2*i)+1]); //MSB, LSB
	}
}

void WDT_service(void)		//feed the watchdog timer
{
	if(BPSstate == 4)  		//we don't service the watchdog timer if the BPS is in an error status
		return;
	if(lastWDToutput)		//toggle the WDT output pin
	{
		misc_setWDT(0);
		lastWDToutput = 0;
	}
	else
	{
		misc_setWDT(1);
		lastWDToutput = 1;
	}		
}	

void serviceMiscTask(void)
{
}
	
void serviceCommands(void)
{
}

//returns 1 if the batteries are within limits, 0 otherwise.	
unsigned char checkLimits(void)
{
	unsigned char checkingA;
	unsigned char hightemp;
	unsigned char lowtemp;
	unsigned char i;
	if(BPSstate != 2)				//don't bother checking the limits if we aren't in the ready state
		return 0;
	if(!(arrayAgood || arrayBgood)) //it's bad if neither array is OK, this means that the system did not yet read the cells
		return 0;
	if(arrayAgood)
		checkingA = 1;
	else if(arrayBgood)
		checkingA = 0;
	else
		return 0;
	if(checkingA)
	{
		if(currentA > reg_read(4,3))  //charging current
			return 0;
		if(currentA < -reg_read(4,4)) //discharging current
			return 0;	
	}
	else
	{
		if(currentB > reg_read(4,3))
			return 0;
		if(currentB < -reg_read(4,4))
			return 0;	
	}				
	
	if(checkingA)
	{
		if(currentA > 0)
		{
			hightemp = reg_read(4,5);
			lowtemp = reg_read(4,6);
		}	
		else
		{
			hightemp = reg_read(4,7);
			lowtemp = reg_read(4,8);
		}	
	}
	else
	{
		if(currentB > 0)
		{
			hightemp = reg_read(4,5);
			lowtemp = reg_read(4,6);
		}	
		else
		{
			hightemp = reg_read(4,7);
			lowtemp = reg_read(4,8);
		}	
	}		
	
	if(checkingA) 
	{
		for(i = 0; i < reg_read(3,1); i++)
		{
			if(batteryVoltsA[i] > reg_read(4,1))
				return 0;
			if(batteryVoltsA[i] < reg_read(4,2))
				return 0;
			if(batteryTempsA[i] > hightemp)
				return 0;
			if(batteryTempsA[i] < lowtemp)
				return 0;
		}	
	}
	else
	{
		for(i = 0; i < reg_read(3,1); i++)
		{
			if(batteryVoltsB[i] > reg_read(4,1))
				return 0;
			if(batteryVoltsB[i] < reg_read(4,2))
				return 0;
			if(batteryTempsB[i] > hightemp)
				return 0;
			if(batteryTempsB[i] < lowtemp)
				return 0;
		}	
	}			
	return 1; //hey, no bad readings!
}	

void updateSOC(void)
{
}	

void contactorControl(unsigned char battLimitStatus)
{
//	unsigned char BPSstate;		//0 = system is "off" and not measuring any cells, contactor is off
							//1 = system is measuring cell values but contactor is off
							//2 = system is on measuring cells and the contactor is on
							//3 = system is tripped, also is measuring batteries, contacotr off
							//4 = system has an error, contactor off, not measuring
	if((BPSstate != 2) && battLimitStatus)
	{
		//contactor is on
	}	
	else
	{
		//contactor is off
	}
	if((BPSstate == 2) && (!battLimitStatus))
		BPSstate = 3;
}	

//newline
