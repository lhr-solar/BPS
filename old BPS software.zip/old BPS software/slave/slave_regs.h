/*******************************************************
/slave_regs.h
/this is a list of the registers for the slave boards
/Fred Engelkemeir, Summer 2012
*******************************************************/

#define GROUP_CONFIG 		1
#define GROUP_LTC_GAIN 		2
#define GROUP_LTC_OFFSET 	3
#define GROUP_TEMP_GAIN 	4
#define GROUP_TEMP_OFFSET 	5

//GROUP_CONFIG's registers

#define REG_CONFIG_ID		1
