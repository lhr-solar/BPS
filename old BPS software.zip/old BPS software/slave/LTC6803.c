/*******************************************************
/LTC6803.c
/Implements the Linear Technologies LTC6803 driver
/LTC6803 is a (code compatible) improved version of the LTC6802
/uses SPI.c and SPI2 port
/uses TIMER3 (mostly to give enough time for the AD conversions to occur)
/Fred Engelkemeir, summer 2012
/Based on Archer Finley's code, spr 2010. THANKS!
*******************************************************/

#include <p30F6012A.h>

#define LTC_WAIT_COUNT 65000 //(40000=16ms at 2.5Mhz Fcy)

int LTC_waiting;			//flag for the timer

void LTC_readConfig(char *configs);
unsigned char LTC_setConfig(CFG0, CFG1, CFG2, CFG3, CFG4, CFG5);
void LTC_startConversion(void);
void LTC_startOWConversion(void);
char LTC_readVoltage(char *voltages);
char LTC_checkPEC(char *data, char PEC);
void LTC_sortVoltages(char *input, unsigned int *output);
void LTC_scaleVoltages(unsigned int *voltages);
int LTC_OWcompare(unsigned int *voltages, unsigned int *OWvoltages);
void LTC_startTimer(void);
void LTC_waitConversion(void);
void LTC_timerInitialize(void);
void LTC_sendPoll(void);



void LTC_readConfig(char *configs)
{
	SPI_chipSelectOn();
	SPI_sendReceive(0x02);
	SPI_receiveArray(configs, 6);
	SPI_chipSelectOff();
}

unsigned char LTC_setConfig(CFG0, CFG1, CFG2, CFG3, CFG4, CFG5)
{
	char configs[6];
	SPI_chipSelectOn();
	SPI_sendReceive(1);
	SPI_sendReceive(CFG0);
	SPI_sendReceive(CFG1);
	SPI_sendReceive(CFG2);
	SPI_sendReceive(CFG3);
	SPI_sendReceive(CFG4);
	SPI_sendReceive(CFG5);
	SPI_chipSelectOff();
	LTC_readConfig(configs);
	if(CFG0 != configs[0])
		return 1;
	if(CFG1 != configs[1])
		return 1;
	if(CFG2 != configs[2])
		return 1;
	if(CFG3 != configs[3])
		return 1;
	if(CFG4 != configs[4])
		return 1;
	if(CFG5 != configs[5])
		return 1;
	return 0;		//it worked, return 0
}

void LTC_startConversion(void)
{
	SPI_chipSelectOn();
	SPI_sendReceive(0x10);
	SPI_chipSelectOff();
}

void LTC_startOWConversion(void)
{
	SPI_chipSelectOn();
	SPI_sendReceive(0x20);
	SPI_chipSelectOff();
}

char LTC_readVoltage(char *voltages)
{
	char PEC;
	SPI_chipSelectOn();
	SPI_sendReceive(0x04);
	SPI_receiveArray(voltages, 18);
	PEC = SPI_sendReceive(0);
	SPI_chipSelectOff();
	return LTC_checkPEC(voltages, PEC);
}



//return 0 if good, 1 if bad
char LTC_checkPEC(char *data, char PEC)
{
	//TODO: do something
	return 0;
}

void LTC_sortVoltages(char *input, unsigned int *output)
{	//written by Archer
	int i;
	int j;
	int buffer;
	for(j=0, i=1; i < 17; )
	{
		output[j] = (int)input[i-1];
		output[j] &= 0x00FF;
		buffer = (int)input[i];
		buffer &= 0x0F;
		buffer = buffer<<8;
		output[j] += buffer;
		output[j+1] = (int)input[i];
		output[j+1] &= 0x0F;
		output[j+1] = output[j+1]>>4;
		output[j+1] += (int)input[i+1]<<4;
		output[j+1] &= 0x0FFF;
		i += 3;
		j += 2;
	}
}

void LTC_scaleVoltages(unsigned int *voltages)
{
	//TODO: get the gain and offset from the register system
	int i;
	for(i = 0; i < 12; i++)
	{
		voltages[i] = voltages[i] * 15;
	}
}

int LTC_OWcompare(unsigned int *voltages, unsigned int *OWvoltages)
{
	int OWgood = 1;
	unsigned int OWlowThresh = 1000;		//TODO: get from the register system
	unsigned int OWhighThresh = 1000;
	int i;
	for(i = 0; i < 12; i++)
	{
		if(OWvoltages[i] > (voltages[i] + OWhighThresh))
			OWgood = 0;
		if(OWvoltages[i] < (voltages[i] - OWlowThresh))
			OWgood = 0;		 
	}
	return OWgood;
}

void LTC_sendPoll(void)
{
	SPI_chipSelectOn();
	SPI_sendReceive(0x40);
	SPI_chipSelectOff();
}	

void LTC_startTimer(void)
{
	TMR3 = 0;
	T3CONbits.TON = 1;
	LTC_waiting = 1;
}


void LTC_waitConversion(void)
{
	while(LTC_waiting);
}

void LTC_timerInitialize(void)
{
	T3CONbits.TGATE = 0;	//don't gate it
	T3CONbits.TCKPS0 = 0;	//1:1 (no) prescaller
	T3CONbits.TCKPS1 = 0;
	T3CONbits.TCS = 0;		//use Fcy clock
	PR3 = LTC_WAIT_COUNT;	//load the timer period register
	IFS0bits.T3IF = 0;		//clear interrupt flag
	IEC0bits.T3IE = 1;		//enable interrupt
}

void __attribute__((__interrupt__, auto_psv)) _T3Interrupt(void)
{
	IFS0bits.T3IF = 0;
	T3CONbits.TON = 0;
	LTC_waiting = 0;
}

//why the hell does it need a newline at the end of the damn file?!?!?!?



