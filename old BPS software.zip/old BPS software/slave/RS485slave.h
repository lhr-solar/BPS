//stupid fucking header file

void RS485_initialize();

